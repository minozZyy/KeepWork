package com.mySpace.homeWork.stage3.model1.mr;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

public class FileReducer extends Reducer<WordSeq, NullWritable, Text, Text> {

    //用于输出序号
    int num=0;
    @Override
    protected void reduce(WordSeq key, Iterable<NullWritable> values, Context context) throws IOException, InterruptedException {

        //循环values值
        for (NullWritable value : values) {
            num +=1;
            context.write(new Text(String.valueOf(num)),new Text(key.getWord()));
        }
    }
}
