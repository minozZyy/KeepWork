package com.mySpace.homeWork.stage3.model1.util;

import java.io.File;

public class FileUtil {

    public static void deleteFile(File file){
        if(file.exists()) {
            if (file.isFile()) {
                file.delete();
            } else {
                for (File file1 : file.listFiles()) {
                    deleteFile(file1);
                }
                file.delete();
            }
        }
    }
}
