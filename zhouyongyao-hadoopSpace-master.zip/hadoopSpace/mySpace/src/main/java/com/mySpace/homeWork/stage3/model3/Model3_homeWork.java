package com.mySpace.homeWork.stage3.model3;

public class Model3_homeWork {

    public static void main(String[] args) {
        System.out.println("查看:dataSpace/stage3/model3");
    }
}
