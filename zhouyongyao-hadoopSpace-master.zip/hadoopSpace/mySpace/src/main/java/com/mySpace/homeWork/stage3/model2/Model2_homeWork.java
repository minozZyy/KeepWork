package com.mySpace.homeWork.stage3.model2;

public class Model2_homeWork {

    public static void main(String[] args) {
        System.out.println("查看:dataSpace/stage3/model2");
    }
}
