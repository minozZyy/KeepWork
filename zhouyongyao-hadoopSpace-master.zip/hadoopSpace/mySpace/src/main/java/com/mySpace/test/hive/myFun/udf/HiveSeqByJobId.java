package com.mySpace.test.hive.myFun.udf;

import org.apache.hadoop.hive.ql.exec.MapredContext;
import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDF;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;

public class HiveSeqByJobId extends GenericUDF {
    private String jobname;

    @Override
    public void configure(MapredContext context) {
        if (null != context) {
            jobname = context.getJobConf().getJobName();
        }
    }

    @Override
    public ObjectInspector initialize(ObjectInspector[] objectInspectors) throws UDFArgumentException {

        if(objectInspectors.length > 1){
            throw new UDFArgumentException("The parameter is abnormal, it must be 0 or 1");
        }
        if(objectInspectors.length == 1 && !(Integer.parseInt(objectInspectors[0].toString()) >= 32) ) {
            throw new UDFArgumentException("The parameter is abnormal, if 1 parameter, it must be greater than 32");
        }
        return PrimitiveObjectInspectorFactory.javaStringObjectInspector;
    }

    @Override
    public Object evaluate(DeferredObject[] deferredObjects) throws HiveException {
        if(jobname == null || jobname == ""){
            jobname = "zhouyy111";
        }
        return jobname;
    }

    @Override
    public String getDisplayString(String[] strings) {
        return "Usage: HiveSeqByJobId(String str) or HiveSeqByJobId()";
    }
}
