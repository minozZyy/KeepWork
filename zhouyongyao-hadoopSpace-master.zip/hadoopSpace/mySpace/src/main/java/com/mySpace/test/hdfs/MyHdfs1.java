package com.mySpace.test.hdfs;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

public class MyHdfs1 {

    public static void main(String[] args) throws URISyntaxException, IOException, InterruptedException {

        //����hdfs
        Configuration configuration = new Configuration();
        //�����ļ�������
        // configuration.set("dfs.replication","1");
        FileSystem fileSystem = FileSystem.get(new URI("hdfs://192.168.10.101:9000"), configuration, "root");

        HdfsFileUtil hdfsUtil = new HdfsFileUtil();

        //System.out.println(hdfsUtil.isExists(fileSystem,new Path("/myDir"))?"����":"������");

        //��ȡĿ¼�ļ���Ϣ
        //hdfsUtil.fileList(fileSystem,new Path("/myDir/file2.txt"));

        //�ӱ����ϴ��ļ�
        //fileSystem.copyFromLocalFile(new Path("F:\\giteeSpace\\hadoopSpace\\dataSpace\\stage3\\model1\\int\\file2.txt"),new Path("/myDir"));

        //��hdfs�����ļ�
        //fileSystem.copyToLocalFile(new Path("/myDir/file2.txt"),new Path("F:\\giteeSpace\\hadoopSpace\\dataSpace\\stage3\\model1\\out"));

    }
}
