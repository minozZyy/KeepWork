package com.mySpace.homeWork.stage3.model1.mr;

import com.mySpace.homeWork.stage3.model1.util.FileUtil;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import java.io.File;
import java.io.IOException;

public class FileDriver {

    public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {

        //指定输入/输出目录
        String intputDataPath = "F:\\giteeSpace\\hadoopSpace\\dataSpace\\stage3\\model1\\int";
        String outputDataPath = "F:\\giteeSpace\\hadoopSpace\\dataSpace\\stage3\\model1\\out";

        System.out.println("数据源:dataSpace/stage3/model1/int");
        System.out.println("数据结果:dataSpace/stage3/model1/out");

        //本地系统运行下，判断输出文件是否存在，存在就删除
        //yarn运行就需要注释这段代码，修改为hdfs的目录删除
        File outpathFile = new File(outputDataPath);
        FileUtil.deleteFile(outpathFile);

//        1. 获取配置文件对象，获取job对象实例
        final Configuration conf = new Configuration();
        final Job job = Job.getInstance(conf, "FileDriver");
//        2. 指定程序jar的本地路径
        job.setJarByClass(FileDriver.class);
//        3. 指定Mapper/Reducer类
        job.setMapperClass(FileMapper.class);
        job.setReducerClass(FileReducer.class);
//        4. 指定Mapper输出的kv数据类型
        job.setMapOutputKeyClass(WordSeq.class);
        job.setMapOutputValueClass(NullWritable.class);
//        5. 指定最终输出的kv数据类型
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);
//        6. 执行reduct的task数量
        job.setNumReduceTasks(1);
//        7. 指定job读取数据路径
        FileInputFormat.setInputPaths(job, new Path(intputDataPath)); //指定读取数据的原始路径
//        8. 指定job输出结果路径
        FileOutputFormat.setOutputPath(job, new Path(outputDataPath)); //指定结果数据输出路径

//        9. 提交作业
        final boolean flag = job.waitForCompletion(true);
        //jvm退出：正常退出0，非0值则是错误退出
        System.exit(flag ? 0 : 1);

    }
}
