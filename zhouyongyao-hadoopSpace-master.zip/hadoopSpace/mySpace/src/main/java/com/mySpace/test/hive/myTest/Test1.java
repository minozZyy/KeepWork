package com.mySpace.test.hive.myTest;

import com.alibaba.fastjson.JSONObject;

import java.util.Random;
import java.util.Set;

public class Test1 {

    public static void main(String[] args) {

        System.out.println(String.valueOf(111));
    }
}
