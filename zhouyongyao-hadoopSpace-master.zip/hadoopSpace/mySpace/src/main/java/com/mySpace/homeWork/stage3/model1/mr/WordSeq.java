package com.mySpace.homeWork.stage3.model1.mr;

import org.apache.hadoop.io.WritableComparable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class WordSeq implements WritableComparable<WordSeq> {
    private int seq;
    private String word;

    public int getSeq() {
        return seq;
    }

    public void setSeq(int seq) {
        this.seq = seq;
    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public WordSeq() {
    }

    public WordSeq(int seq, String word) {
        this.seq = seq;
        this.word = word;
    }

    public void write(DataOutput dataOutput) throws IOException {
        dataOutput.writeInt(seq);
        dataOutput.writeUTF(word);
    }

    public void readFields(DataInput dataInput) throws IOException {
        this.seq = dataInput.readInt();
        this.word = dataInput.readUTF();
    }

    public int compareTo(WordSeq o) {
        int num1 = Integer.parseInt(this.word);
        int num2 = Integer.parseInt(o.word);
        if(num1 > num2){
            return 1;
        }else if(num1 < num2){
            return -1;
        }else {
            return 0;
        }
    }

}
