package com.mySpace.test.hdfs;

import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

import java.io.IOException;
import java.util.List;

//��������hdfs�ļ��Ĳ���
public class HdfsFileUtil {

    //�ж��ļ��Ƿ����
    public boolean isExists(FileSystem fileSystem, Path file){
        boolean res = false;
        try {
            res = fileSystem.exists(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return res;
    }

    public FileStatus[] fileList(FileSystem fileSystem, Path file){
        FileStatus[] fileStatuses = new FileStatus[0];
        try {
            fileStatuses = fileSystem.listStatus(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
        for (int i = 0; i < fileStatuses.length; i++) {
            System.out.println(fileStatuses[i]);
        }
        return fileStatuses;
    }
    //public
}
