package com.myJob.seq;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.MapredContext;
import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.UDFType;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDF;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;

import java.util.Random;

@Description(name = "HiveSeqByJobId",
        value = "_FUNC_()",
        extended = "HiveSeqByJobId()")
@UDFType(deterministic = false ,stateful = true)
public class HiveSeqByJobId extends GenericUDF {
    //返回的jobid，attempt_1622273771564_0010_m_000000_0
    private String seqNum = "";
    //自增的序号数
    private int addSeq = 0;
    //返回的最大长度
    private int maxLen = 38;
    //中间补充的0
    private String zeroStr = "00000000000000000000000000000000000000000000000000";
    //通过时间生成seqNum时，组合的数据数范围
    private int randomSize = 1000000001;

    public void configure(MapredContext context) {
        if (null != context) {
            String taskId = context.getJobConf().get("mapred.task.id");
            //attempt_1622273771564_0011_m_000000_0
            //162227377156400100000000
            String[] taskIdArr = taskId.split("_");
            if(taskIdArr.length == 6 ){
                seqNum = taskIdArr[1] + taskIdArr[2] + taskIdArr[4] + taskIdArr[5];
            }
        }else{
            seqNum = getseqByTime();
        }
    }

    public ObjectInspector initialize(ObjectInspector[] objectInspectors) throws UDFArgumentException {
        //参数判断
        if(objectInspectors.length >= 1){
            throw new UDFArgumentException("The parameter is abnormal");
        }
        //函数返回值类型
        return PrimitiveObjectInspectorFactory.javaStringObjectInspector;
    }

    public Object evaluate(DeferredObject[] deferredObjects) throws HiveException {
        if(null == seqNum || seqNum.length() == 0){
            seqNum = getseqByTime();
        }
        String addSeqOfRes = addSeq() + "";
        String seq = seqNum + addSeqOfRes;
        String seqNumOfRes = seqNum + zeroStr.substring(0,maxLen - seq.length()) + addSeqOfRes;
        return seqNumOfRes;
    }

    public String getDisplayString(String[] strings) {
        return "Usage: HiveSeqByJobId()";
    }

    //获取以微秒生成的seq
    private String getseqByTime(){
        String res = "";
        //获取微妙数
        long nanoTime = System.nanoTime(); //77651060461100
        //获取随机数
        Random random = new Random();
        int randomNum = random.nextInt(randomSize);
        res = nanoTime + "" + randomNum;

        return res;
    }

    //序号自增
    public synchronized int addSeq() {
        addSeq++;
        return addSeq;
    }
}
