package com.myJob.json;

import com.alibaba.fastjson.JSONObject;
import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.exec.UDFArgumentLengthException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDTF;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class JsonToTabCol extends GenericUDTF {
    //用于存储key
    private Map<String, Integer> keyMap = new HashMap<String, Integer>();
    //用于记录key的序号
    private int keySeq = 0;

    public StructObjectInspector initialize(ObjectInspector[] args) throws UDFArgumentException {
        if (args.length != 1) {
            throw new UDFArgumentLengthException("ExplodeMap takes only one argument");
        }
        if (args[0].getCategory() != ObjectInspector.Category.PRIMITIVE) {
            throw new UDFArgumentException("ExplodeMap takes string as a parameter");
        }

        //定义返回值个数及类型
        ArrayList<String> fieldNames = new ArrayList<String>();
        ArrayList<ObjectInspector> fieldOIs = new ArrayList<ObjectInspector>();

        fieldNames.add("rowid");
        fieldOIs.add(PrimitiveObjectInspectorFactory.javaStringObjectInspector);
        fieldNames.add("key");
        fieldOIs.add(PrimitiveObjectInspectorFactory.javaStringObjectInspector);
        fieldNames.add("val");
        fieldOIs.add(PrimitiveObjectInspectorFactory.javaStringObjectInspector);

        return ObjectInspectorFactory.getStandardStructObjectInspector(fieldNames, fieldOIs);
    }

    public void process(Object[] objects) throws HiveException {
        //{"rowid":101,"info":{"name":"zhou1","age":11,"sex":1,"address":"a"}}
        String input = objects[0].toString();
        JSONObject jsonObject = JSONObject.parseObject(input);
        String rowid = jsonObject.getString("rowid");

        JSONObject infoObject = jsonObject.getJSONObject("info");
        Set<String> keySet = infoObject.keySet();

        String[] result = new String[3];
        for (String key : keySet) {
            if(!keyMap.containsKey(key)){
                keySeq++;
                keyMap.put(key,keySeq);
            }
            result[0] = rowid;
            result[1] = String.valueOf(key);
            result[2] = String.valueOf(infoObject.get(key));
            forward(result);
        }
    }

    public void close() throws HiveException {

    }
}
