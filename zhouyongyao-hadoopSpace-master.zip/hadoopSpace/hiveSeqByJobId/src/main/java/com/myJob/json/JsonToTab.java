package com.myJob.json;

import com.alibaba.fastjson.JSONObject;
import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.exec.UDFArgumentLengthException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDTF;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.StructField;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.WritableConstantStringObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.WritableStringObjectInspector;
import org.apache.hadoop.io.Text;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class JsonToTab extends GenericUDTF {
    private Map<String,String> keySeqMap = new HashMap<String,String>();
    private int keyLen = 0;

    public StructObjectInspector initialize(ObjectInspector[] args) throws UDFArgumentException {
        if (args.length != 2) {
            throw new UDFArgumentLengthException("ExplodeMap takes only one argument");
        }
        if (args[0].getCategory() != ObjectInspector.Category.PRIMITIVE) {
            throw new UDFArgumentException("ExplodeMap takes string as a parameter");
        }

        Text writableConstantValue = ((WritableConstantStringObjectInspector) args[1]).getWritableConstantValue();

        String[] keyStr = writableConstantValue.toString().split(",");
        keyLen = keyStr.length;

        //定义返回值个数及类型
        ArrayList<String> fieldNames = new ArrayList<String>();
        ArrayList<ObjectInspector> fieldOIs = new ArrayList<ObjectInspector>();

        fieldNames.add("rowid");
        fieldOIs.add(PrimitiveObjectInspectorFactory.javaStringObjectInspector);

        for (String key : keyStr) {
            String[] keySeq = key.split(":");
            keySeqMap.put(keySeq[0],keySeq[1]);
            fieldNames.add(keySeq[1]);
            fieldOIs.add(PrimitiveObjectInspectorFactory.javaStringObjectInspector);
        }
        return ObjectInspectorFactory.getStandardStructObjectInspector(fieldNames, fieldOIs);
    }

    public void process(Object[] objects) throws HiveException {
        //{"rowid":101,"info":{"name":"zhou1","age":11,"sex":1,"address":"a"}}
        String input = objects[0].toString();
        JSONObject jsonObject = JSONObject.parseObject(input);
        String rowid = jsonObject.getString("rowid");
        JSONObject infoObject = jsonObject.getJSONObject("info");

        String[] result = new String[(keyLen + 1)];
        result[0] = rowid;
        // 遍历key
        for (String keySeq : keySeqMap.keySet()) {
            result[Integer.parseInt(keySeq)] = String.valueOf(infoObject.get(keySeqMap.get(keySeq)));
        }
        forward(result);
    }

    public void close() throws HiveException {}
}
